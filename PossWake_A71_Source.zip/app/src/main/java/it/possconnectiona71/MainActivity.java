package it.possconnectiona71;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    static final String PREFS = "posswake_settings";
    static final String KEY_ACTIVE = "active";

    private TextView status;
    private TextView help;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        status = findViewById(R.id.status);
        help = findViewById(R.id.help);
        Button enable = findViewById(R.id.enable);
        Button disable = findViewById(R.id.disable);
        Button accessibility = findViewById(R.id.accessibility);

        enable.setOnClickListener(v -> {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_ACTIVE, true).apply();
            refresh();
            if (!ScreenWakeService.isConnected()) {
                Toast.makeText(this, "Ora abilita PossWake A71 in Accessibilità", Toast.LENGTH_LONG).show();
                openAccessibility();
            } else {
                Toast.makeText(this, "Attivo: spegni lo schermo per provare", Toast.LENGTH_LONG).show();
            }
        });
        disable.setOnClickListener(v -> {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_ACTIVE, false).apply();
            ScreenWakeService.abortCurrentCycle();
            refresh();
            Toast.makeText(this, "Riaccensione automatica disattivata", Toast.LENGTH_SHORT).show();
        });
        accessibility.setOnClickListener(v -> openAccessibility());
        refresh();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        if (status == null) return;
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        boolean enabled = prefs.getBoolean(KEY_ACTIVE, false);
        boolean service = ScreenWakeService.isConnected();
        if (enabled && service) {
            status.setText("● ATTIVO");
            status.setTextColor(0xFF4ED2BD);
            help.setText("Premi il tasto laterale per spegnere lo schermo. Dopo 3 secondi si riaccende, rimane acceso 3 secondi e si spegne.");
        } else if (enabled) {
            status.setText("● ACCESSIBILITÀ DA ATTIVARE");
            status.setTextColor(0xFFFFCB77);
            help.setText("Apri Accessibilità > App installate > PossWake A71 – controllo schermo > Attiva.");
        } else {
            status.setText("● DISATTIVATO");
            status.setTextColor(0xFF9AB6C1);
            help.setText("Tocca ATTIVA e autorizza il servizio di Accessibilità, se richiesto.");
        }
    }

    private void openAccessibility() {
        startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
    }
}
