package it.possconnectiona71;
import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.provider.Settings;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.view.accessibility.AccessibilityManager;
import android.widget.Switch;
public class MainActivity extends Activity {
  static final String PREFS="posswake_settings", KEY_ACTIVE="active";
  private Switch toggle;
  private boolean suppress=false;
  @Override public void onCreate(Bundle s){
    super.onCreate(s);setContentView(R.layout.activity_main);
    toggle=findViewById(R.id.main_switch);
    toggle.setOnCheckedChangeListener((b,on)->{
      if(suppress)return;
      getSharedPreferences(PREFS,MODE_PRIVATE).edit().putBoolean(KEY_ACTIVE,on).apply();
      if(!on) ScreenWakeService.abortCurrentCycle();
      else if(!accessibilityEnabled())startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
    });
  }
  @Override public void onResume(){
    super.onResume();if(toggle==null)return;
    boolean on=getSharedPreferences(PREFS,MODE_PRIVATE).getBoolean(KEY_ACTIVE,false);
    if(on&&!accessibilityEnabled()){on=false;getSharedPreferences(PREFS,MODE_PRIVATE).edit().putBoolean(KEY_ACTIVE,false).apply();}
    suppress=true;toggle.setChecked(on);suppress=false;
  }
  private boolean accessibilityEnabled(){
    AccessibilityManager m=(AccessibilityManager)getSystemService(ACCESSIBILITY_SERVICE);
    if(m==null)return false;
    String id=getPackageName()+"/"+ScreenWakeService.class.getName();
    for(AccessibilityServiceInfo x:m.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK))
      if(id.equals(x.getId()))return true;
    return false;
  }
}