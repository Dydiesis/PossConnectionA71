package it.possconnectiona71;
import android.accessibilityservice.AccessibilityService;
import android.content.*;
import android.os.*;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
@SuppressWarnings("deprecation")
public class ScreenWakeService extends AccessibilityService {
  private static final String TAG="PossWakeA71";
  private static volatile ScreenWakeService instance;
  private static final int IDLE=0, WAITING=1, WAKING=2;
  private final Handler h=new Handler(Looper.getMainLooper());
  private int stage=IDLE;
  private PowerManager power;
  private PowerManager.WakeLock cpu,display;
  private boolean registered=false;
  private long ignoreOffUntil=0;
  private Runnable pendingWake,pendingOff,pendingFallback;
  static boolean isConnected(){return instance!=null;}
  static void abortCurrentCycle(){ScreenWakeService s=instance;if(s!=null)s.h.post(s::reset);}
  static void onWakeActivityVisible(){ScreenWakeService s=instance;if(s!=null)s.h.post(s::scheduleOff);}
  private boolean active(){
    return getSharedPreferences(MainActivity.PREFS,MODE_PRIVATE).getBoolean(MainActivity.KEY_ACTIVE,false);
  }
  private final BroadcastReceiver listener=new BroadcastReceiver(){
    @Override public void onReceive(Context c,Intent i){
      if(i==null)return;String a=i.getAction();
      if(Intent.ACTION_SCREEN_OFF.equals(a)){
        if(SystemClock.elapsedRealtime()<ignoreOffUntil){ignoreOffUntil=0;return;}
        if(stage==WAKING){reset();return;}
        begin();
      }else if(Intent.ACTION_SCREEN_ON.equals(a)){
        if(stage==WAITING)reset();
        else if(stage==WAKING)scheduleOff();
      }else if(Intent.ACTION_USER_PRESENT.equals(a))reset();
    }
  };
  @Override protected void onServiceConnected(){
    super.onServiceConnected();instance=this;power=(PowerManager)getSystemService(POWER_SERVICE);
    if(!registered){
      IntentFilter f=new IntentFilter();
      f.addAction(Intent.ACTION_SCREEN_OFF);f.addAction(Intent.ACTION_SCREEN_ON);
      f.addAction(Intent.ACTION_USER_PRESENT);
      registerReceiver(listener,f);registered=true;
    }
  }
  private void begin(){
    if(!active()||power==null)return;
    reset();stage=WAITING;
    try{
      cpu=power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,TAG+":cpu");
      cpu.acquire(11000L);
    }catch(RuntimeException e){Log.e(TAG,"CPU wake failure",e);reset();return;}
    pendingWake=()->{
      pendingWake=null;
      if(stage!=WAITING||!active()||power.isInteractive()){reset();return;}
      stage=WAKING;
      try{
        display=power.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK|PowerManager.ACQUIRE_CAUSES_WAKEUP,TAG+":display");
        display.acquire(5000L);
      }catch(RuntimeException e){Log.w(TAG,"Legacy display wake failed",e);releaseDisplay();}
      try{
        Intent i=new Intent(this,WakeScreenActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS|Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(i);
      }catch(RuntimeException e){Log.w(TAG,"Wake activity failed",e);}
      pendingFallback=()->{
        pendingFallback=null;
        if(stage==WAKING&&power.isInteractive())scheduleOff();
        else if(stage==WAKING)reset();
      };
      h.postDelayed(pendingFallback,1000L);
    };
    h.postDelayed(pendingWake,3000L);
  }
  private void scheduleOff(){
    if(stage!=WAKING||!active()||power==null||!power.isInteractive()||pendingOff!=null)return;
    if(pendingFallback!=null){h.removeCallbacks(pendingFallback);pendingFallback=null;}
    pendingOff=()->{
      pendingOff=null;
      if(stage==WAKING&&active()&&power.isInteractive()){
        ignoreOffUntil=SystemClock.elapsedRealtime()+5000L;
        releaseDisplay();
        boolean ok=performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN);
        if(!ok)ignoreOffUntil=0L;
      }
      reset();
    };
    h.postDelayed(pendingOff,3000L);
  }
  private void releaseDisplay(){
    if(display!=null){try{if(display.isHeld())display.release();}catch(RuntimeException ignored){}display=null;}
  }
  private void reset(){
    if(pendingWake!=null)h.removeCallbacks(pendingWake);
    if(pendingOff!=null)h.removeCallbacks(pendingOff);
    if(pendingFallback!=null)h.removeCallbacks(pendingFallback);
    pendingWake=pendingOff=pendingFallback=null;stage=IDLE;releaseDisplay();
    if(cpu!=null){try{if(cpu.isHeld())cpu.release();}catch(RuntimeException ignored){}cpu=null;}
  }
  @Override public void onAccessibilityEvent(AccessibilityEvent e){}
  @Override public void onInterrupt(){}
  @Override public void onDestroy(){
    reset();if(registered){try{unregisterReceiver(listener);}catch(IllegalArgumentException ignored){}registered=false;}
    if(instance==this)instance=null;super.onDestroy();
  }
}