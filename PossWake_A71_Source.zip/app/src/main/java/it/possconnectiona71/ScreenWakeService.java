package it.possconnectiona71;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Path;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import java.util.ArrayDeque;
import java.util.Locale;

@SuppressWarnings("deprecation")
public class ScreenWakeService extends AccessibilityService {
  private static final String TAG="PossWakeA71";
  private static volatile ScreenWakeService instance;
  private static final int IDLE=0, WAITING=1, WAKING=2;
  private final Handler h=new Handler(Looper.getMainLooper());
  private int stage=IDLE;
  private PowerManager power;
  private PowerManager.WakeLock cpu,display;
  private boolean registered=false;
  private long ignoreOffUntil=0;
  private Runnable pendingWake,pendingOff,pendingFallback,dataScan;
  private boolean dataAttemptStarted=false,dataTileClicked=false,expanded=false;
  private boolean confirmationClicked=false;
  private int scans=0;

  static void abortCurrentCycle(){
    ScreenWakeService s=instance;
    if(s!=null)s.h.post(s::reset);
  }
  static void onWakeActivityVisible(){
    ScreenWakeService s=instance;
    if(s!=null)s.h.post(()->{s.scheduleOff();s.startDataOff();});
  }

  private boolean active(){
    return getSharedPreferences(MainActivity.PREFS,MODE_PRIVATE)
      .getBoolean(MainActivity.KEY_ACTIVE,false);
  }

  private final BroadcastReceiver listener=new BroadcastReceiver(){
    @Override public void onReceive(Context c,Intent i){
      if(i==null)return;
      String action=i.getAction();
      if(Intent.ACTION_SCREEN_OFF.equals(action)){
        if(SystemClock.elapsedRealtime()<ignoreOffUntil){
          ignoreOffUntil=0;return;
        }
        if(stage==WAKING){reset();return;}
        begin();
      } else if(Intent.ACTION_SCREEN_ON.equals(action)){
        if(stage==WAITING)reset();
        else if(stage==WAKING){scheduleOff();startDataOff();}
      } else if(Intent.ACTION_USER_PRESENT.equals(action)){
        reset();
      }
    }
  };

  @Override protected void onServiceConnected(){
    super.onServiceConnected();
    instance=this;
    power=(PowerManager)getSystemService(POWER_SERVICE);
    if(!registered){
      IntentFilter filter=new IntentFilter();
      filter.addAction(Intent.ACTION_SCREEN_OFF);
      filter.addAction(Intent.ACTION_SCREEN_ON);
      filter.addAction(Intent.ACTION_USER_PRESENT);
      registerReceiver(listener,filter);
      registered=true;
    }
  }

  private void begin(){
    if(!active()||power==null)return;
    reset();
    stage=WAITING;
    try{
      cpu=power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,TAG+":cpu");
      cpu.acquire(16000L);
    }catch(RuntimeException ex){
      Log.e(TAG,"CPU wake failed",ex);
      reset();return;
    }
    pendingWake=()->{
      pendingWake=null;
      if(stage!=WAITING||!active()||power.isInteractive()){
        reset();return;
      }
      stage=WAKING;
      try{
        display=power.newWakeLock(
          PowerManager.SCREEN_BRIGHT_WAKE_LOCK|PowerManager.ACQUIRE_CAUSES_WAKEUP,
          TAG+":display");
        display.acquire(10000L);
      }catch(RuntimeException ex){
        Log.w(TAG,"Legacy wake lock failed",ex);
        releaseDisplay();
      }
      try{
        Intent wake=new Intent(this,WakeScreenActivity.class);
        wake.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|
          Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS|
          Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(wake);
      }catch(RuntimeException ex){
        Log.w(TAG,"Wake screen activity failed",ex);
      }
      pendingFallback=()->{
        pendingFallback=null;
        if(stage==WAKING&&power.isInteractive()){
          scheduleOff();
          startDataOff();
        }else if(stage==WAKING)reset();
      };
      h.postDelayed(pendingFallback,1000L);
    };
    h.postDelayed(pendingWake,3000L);
  }

  private void scheduleOff(){
    if(stage!=WAKING||!active()||power==null||
       !power.isInteractive()||pendingOff!=null)return;
    if(pendingFallback!=null){
      h.removeCallbacks(pendingFallback);
      pendingFallback=null;
    }
    pendingOff=()->{
      pendingOff=null;
      if(stage==WAKING&&active()&&power.isInteractive()){
        ignoreOffUntil=SystemClock.elapsedRealtime()+5000L;
        releaseDisplay();
        if(!performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN))
          ignoreOffUntil=0;
      }
      reset();
    };
    h.postDelayed(pendingOff,6000L);
  }

  // Read-only state. Never toggle without first verifying mobile data is ON.
  private Boolean mobileDataEnabled(){
    try{
      TelephonyManager tm=(TelephonyManager)getSystemService(TELEPHONY_SERVICE);
      if(tm==null)return null;
      return tm.isDataEnabled();
    }catch(SecurityException|UnsupportedOperationException ex){
      Log.w(TAG,"Cannot read mobile data state",ex);
      return null;
    }catch(RuntimeException ex){
      Log.w(TAG,"Mobile data state unavailable",ex);
      return null;
    }
  }

  private void startDataOff(){
    if(stage!=WAKING||!active()||dataAttemptStarted||
       power==null||!power.isInteractive())return;
    dataAttemptStarted=true;
    Boolean enabled=mobileDataEnabled();
    if(!Boolean.TRUE.equals(enabled)){
      Log.i(TAG,enabled==null?"Mobile data state unknown; no toggle":
        "Mobile data already disabled");
      return;
    }
    if(!performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)){
      Log.w(TAG,"Quick settings unavailable on lock screen");
      return;
    }
    scans=0;
    dataScan=new Runnable(){
      @Override public void run(){
        if(stage!=WAKING||!active())return;
        Boolean current=mobileDataEnabled();
        if(Boolean.FALSE.equals(current)){
          Log.i(TAG,"Mobile data disabled successfully");
          performGlobalAction(GLOBAL_ACTION_BACK);
          dataScan=null;
          return;
        }
        if(current==null){
          Log.w(TAG,"Cannot verify mobile data; stop to prevent accidental ON");
          dataScan=null;
          return;
        }
        scans++;
        AccessibilityNodeInfo root=findSystemUiRoot();
        if(root!=null){
          if(dataTileClicked){
            tryConfirmDataOff(root);
          }else{
            AccessibilityNodeInfo tile=findMobileDataTile(root);
            if(tile!=null){
              AccessibilityNodeInfo actionTarget=clickableAncestor(tile);
              if(actionTarget!=null&&actionTarget.performAction(
                  AccessibilityNodeInfo.ACTION_CLICK)){
                dataTileClicked=true;
                Log.i(TAG,"Requested mobile data OFF via quick settings");
              }
            }
          }
        }
        if(scans==4&&!dataTileClicked&&!expanded){
          expanded=true;
          expandQuickPanel();
        }
        if(scans<12){
          h.postDelayed(this,350L);
        }else{
          Log.w(TAG,"Mobile data OFF not confirmed; check Secure lock settings / Lock network and security");
          dataScan=null;
        }
      }
    };
    h.postDelayed(dataScan,300L);
  }

  private AccessibilityNodeInfo findSystemUiRoot(){
    AccessibilityNodeInfo root=getRootInActiveWindow();
    if(root!=null&&isSystemUi(root))return root;
    try{
      for(AccessibilityWindowInfo window:getWindows()){
        if(window==null)continue;
        AccessibilityNodeInfo view=window.getRoot();
        if(view!=null&&isSystemUi(view))return view;
      }
    }catch(RuntimeException e){
      Log.w(TAG,"Cannot retrieve quick settings windows",e);
    }
    return null;
  }

  private boolean isSystemUi(AccessibilityNodeInfo node){
    CharSequence pkg=node.getPackageName();
    return pkg!=null&&pkg.toString().toLowerCase(Locale.ROOT)
      .contains("systemui");
  }

  private String label(AccessibilityNodeInfo n){
    String t=n.getText()==null?"":n.getText().toString();
    String d=n.getContentDescription()==null?"":n.getContentDescription().toString();
    return (t+" "+d).toLowerCase(Locale.ROOT).trim();
  }

  private boolean mobileTileLabel(String s){
    return s.equals("dati mobili")||s.startsWith("dati mobili,")||
      s.startsWith("dati mobili ")||s.startsWith("dati mobili:")||
      s.equals("mobile data")||s.startsWith("mobile data,")||
      s.startsWith("mobile data ")||s.startsWith("mobile data:");
  }

  private AccessibilityNodeInfo findMobileDataTile(AccessibilityNodeInfo root){
    ArrayDeque<AccessibilityNodeInfo> nodes=new ArrayDeque<>();
    nodes.add(root);
    int count=0;
    while(!nodes.isEmpty()&&count++<250){
      AccessibilityNodeInfo n=nodes.removeFirst();
      String l=label(n);
      if(l.length()<125&&mobileTileLabel(l))return n;
      for(int i=0;i<n.getChildCount();i++){
        AccessibilityNodeInfo c=n.getChild(i);
        if(c!=null)nodes.addLast(c);
      }
    }
    return null;
  }

  private AccessibilityNodeInfo clickableAncestor(AccessibilityNodeInfo node){
    AccessibilityNodeInfo current=node;
    for(int i=0;i<5&&current!=null;i++){
      if(current.isClickable()&&current.isEnabled())return current;
      current=current.getParent();
    }
    return null;
  }

  private void tryConfirmDataOff(AccessibilityNodeInfo root){
    ArrayDeque<AccessibilityNodeInfo> nodes=new ArrayDeque<>();
    nodes.add(root);
    boolean mentionsMobile=false;
    AccessibilityNodeInfo confirmation=null;
    int count=0;
    while(!nodes.isEmpty()&&count++<220){
      AccessibilityNodeInfo n=nodes.removeFirst();
      String s=label(n);
      if(s.contains("dati mobili")||s.contains("mobile data"))
        mentionsMobile=true;
      if(s.equals("disattiva")||s.equals("turn off")||
         s.equals("disattiva dati mobili")||s.equals("turn off mobile data"))
        confirmation=clickableAncestor(n);
      for(int i=0;i<n.getChildCount();i++){
        AccessibilityNodeInfo child=n.getChild(i);
        if(child!=null)nodes.addLast(child);
      }
    }
    if(mentionsMobile&&confirmation!=null&&!confirmationClicked){
      if(confirmation.performAction(AccessibilityNodeInfo.ACTION_CLICK)){
        confirmationClicked=true;
        Log.i(TAG,"Confirmed mobile data OFF prompt");
      }
    }
  }

  private void expandQuickPanel(){
    try{
      int w=getResources().getDisplayMetrics().widthPixels;
      int hgt=getResources().getDisplayMetrics().heightPixels;
      Path p=new Path();
      p.moveTo(w*0.50f,hgt*0.16f);
      p.lineTo(w*0.50f,hgt*0.78f);
      GestureDescription.Builder b=new GestureDescription.Builder();
      b.addStroke(new GestureDescription.StrokeDescription(p,0,300L));
      dispatchGesture(b.build(),null,null);
    }catch(RuntimeException ex){
      Log.w(TAG,"Quick settings swipe unavailable",ex);
    }
  }

  private void releaseDisplay(){
    if(display!=null){
      try{if(display.isHeld())display.release();}
      catch(RuntimeException ignored){}
      display=null;
    }
  }

  private void reset(){
    if(pendingWake!=null)h.removeCallbacks(pendingWake);
    if(pendingOff!=null)h.removeCallbacks(pendingOff);
    if(pendingFallback!=null)h.removeCallbacks(pendingFallback);
    if(dataScan!=null)h.removeCallbacks(dataScan);
    pendingWake=pendingOff=pendingFallback=dataScan=null;
    dataAttemptStarted=dataTileClicked=expanded=confirmationClicked=false;
    scans=0;stage=IDLE;
    releaseDisplay();
    if(cpu!=null){
      try{if(cpu.isHeld())cpu.release();}
      catch(RuntimeException ignored){}
      cpu=null;
    }
  }

  @Override public void onAccessibilityEvent(AccessibilityEvent e){}
  @Override public void onInterrupt(){}
  @Override public void onDestroy(){
    reset();
    if(registered){
      try{unregisterReceiver(listener);}
      catch(IllegalArgumentException ignored){}
      registered=false;
    }
    if(instance==this)instance=null;
    super.onDestroy();
  }
}