package it.possconnectiona71;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import java.util.ArrayDeque;
import java.util.Locale;

@SuppressWarnings("deprecation")
public class ScreenWakeService extends AccessibilityService {
  private static final String TAG="PossWakeA71";
  private static volatile ScreenWakeService instance;
  private static final int IDLE=0, WAITING=1, WAKING=2;
  private final Handler h=new Handler(Looper.getMainLooper());
  private int stage=IDLE;
  private PowerManager power;
  private PowerManager.WakeLock cpu,display;
  private boolean registered=false;
  private long ignoreOffUntil=0;
  private Runnable pendingWake,pendingOff,pendingFallback,dataScan,panelSequence;
  private boolean dataAttemptStarted=false,dataTileClicked=false,expanded=false;
  private boolean confirmationClicked=false;
  private boolean detailToggleAttempted=false;
  private int scans=0;

  static void abortCurrentCycle(){
    ScreenWakeService s=instance;
    if(s!=null)s.h.post(s::reset);
  }
  static void onWakeActivityVisible(){
    ScreenWakeService s=instance;
    if(s!=null)s.h.post(()->{s.scheduleOff();s.startDataOff();});
  }

  private boolean active(){
    return getSharedPreferences(MainActivity.PREFS,MODE_PRIVATE)
      .getBoolean(MainActivity.KEY_ACTIVE,false);
  }

  private final BroadcastReceiver listener=new BroadcastReceiver(){
    @Override public void onReceive(Context c,Intent i){
      if(i==null)return;
      String action=i.getAction();
      if(Intent.ACTION_SCREEN_OFF.equals(action)){
        if(SystemClock.elapsedRealtime()<ignoreOffUntil){
          ignoreOffUntil=0;return;
        }
        if(stage==WAKING){reset();return;}
        begin();
      } else if(Intent.ACTION_SCREEN_ON.equals(action)){
        if(stage==WAITING)reset();
        else if(stage==WAKING){scheduleOff();startDataOff();}
      } else if(Intent.ACTION_USER_PRESENT.equals(action)){
        reset();
      }
    }
  };

  @Override protected void onServiceConnected(){
    super.onServiceConnected();
    instance=this;
    power=(PowerManager)getSystemService(POWER_SERVICE);
    if(!registered){
      IntentFilter filter=new IntentFilter();
      filter.addAction(Intent.ACTION_SCREEN_OFF);
      filter.addAction(Intent.ACTION_SCREEN_ON);
      filter.addAction(Intent.ACTION_USER_PRESENT);
      registerReceiver(listener,filter);
      registered=true;
    }
  }

  private void begin(){
    if(!active()||power==null)return;
    reset();
    stage=WAITING;
    try{
      cpu=power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,TAG+":cpu");
      cpu.acquire(16000L);
    }catch(RuntimeException ex){
      Log.e(TAG,"CPU wake failed",ex);
      reset();return;
    }
    pendingWake=()->{
      pendingWake=null;
      if(stage!=WAITING||!active()||power.isInteractive()){
        reset();return;
      }
      stage=WAKING;
      try{
        display=power.newWakeLock(
          PowerManager.SCREEN_BRIGHT_WAKE_LOCK|PowerManager.ACQUIRE_CAUSES_WAKEUP,
          TAG+":display");
        display.acquire(10000L);
      }catch(RuntimeException ex){
        Log.w(TAG,"Legacy wake lock failed",ex);
        releaseDisplay();
      }
      try{
        Intent wake=new Intent(this,WakeScreenActivity.class);
        wake.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|
          Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS|
          Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(wake);
      }catch(RuntimeException ex){
        Log.w(TAG,"Wake screen activity failed",ex);
      }
      pendingFallback=()->{
        pendingFallback=null;
        if(stage==WAKING&&power.isInteractive()){
          scheduleOff();
          startDataOff();
        }else if(stage==WAKING)reset();
      };
      h.postDelayed(pendingFallback,1000L);
    };
    h.postDelayed(pendingWake,3000L);
  }

  private void scheduleOff(){
    if(stage!=WAKING||!active()||power==null||
       !power.isInteractive()||pendingOff!=null)return;
    if(pendingFallback!=null){
      h.removeCallbacks(pendingFallback);
      pendingFallback=null;
    }
    pendingOff=()->{
      pendingOff=null;
      if(stage==WAKING&&active()&&power.isInteractive()){
        ignoreOffUntil=SystemClock.elapsedRealtime()+5000L;
        releaseDisplay();
        if(!performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN))
          ignoreOffUntil=0;
      }
      reset();
    };
    h.postDelayed(pendingOff,6000L);
  }

  // Read-only state. Never toggle without first verifying mobile data is ON.
  private Boolean mobileDataEnabled(){
    try{
      TelephonyManager tm=(TelephonyManager)getSystemService(TELEPHONY_SERVICE);
      if(tm==null)return null;
      return tm.isDataEnabled();
    }catch(SecurityException|UnsupportedOperationException ex){
      Log.w(TAG,"Cannot read mobile data state",ex);
      return null;
    }catch(RuntimeException ex){
      Log.w(TAG,"Mobile data state unavailable",ex);
      return null;
    }
  }

  private void startDataOff(){
    if(stage!=WAKING||!active()||dataAttemptStarted||
       power==null||!power.isInteractive())return;
    dataAttemptStarted=true;
    Boolean enabled=mobileDataEnabled();
    if(!Boolean.TRUE.equals(enabled)){
      Log.i(TAG,enabled==null?"Mobile data state unknown; no toggle":
        "Mobile data already disabled");
      return;
    }
    // Samsung One UI: pull the shade down, then pull down once more
    // before looking for the blue "Conn. dati" quick-settings tile.
    scans=0;
    dataScan=new Runnable(){
      @Override public void run(){
        if(stage!=WAKING||!active())return;
        Boolean current=mobileDataEnabled();
        if(Boolean.FALSE.equals(current)){
          Log.i(TAG,"Mobile data disabled successfully");
          performGlobalAction(GLOBAL_ACTION_BACK);
          dataScan=null;
          return;
        }
        if(current==null){
          Log.w(TAG,"Cannot verify mobile data; stop to prevent accidental ON");
          dataScan=null;
          return;
        }
        scans++;
        AccessibilityNodeInfo root=findSystemUiRoot();
        if(root!=null){
          if(dataTileClicked){
            tryConfirmDataOff(root);
          }else{
            AccessibilityNodeInfo tile=findMobileDataTile(root);
            if(tile!=null){
              AccessibilityNodeInfo actionTarget=clickableAncestor(tile);
              boolean accepted=false;
              if(actionTarget!=null){
                accepted=actionTarget.performAction(AccessibilityNodeInfo.ACTION_CLICK);
              }
              if(!accepted){
                accepted=tapRecognisedTile(tile);
              }
              if(accepted){
                dataTileClicked=true;
                Log.i(TAG,"Requested Conn. dati OFF via Samsung quick settings");
              }
            }
          }
        }
        if(scans==4&&!dataTileClicked&&!expanded){
          expanded=true;
          expandQuickPanel();
        }
        if(scans<12){
          h.postDelayed(this,350L);
        }else{
          Log.w(TAG,"Mobile data OFF not confirmed; check Secure lock settings / Lock network and security");
          dataScan=null;
        }
      }
    };
    // Allow the newly lit lock-screen/SystemUI to finish drawing.
    panelSequence=()->{
      panelSequence=null;
      if(stage==WAKING&&active())pullShadeDown(0);
    };
    h.postDelayed(panelSequence,450L);
  }

  private void scanMobileTile(){
    if(stage==WAKING&&active()&&dataScan!=null){
      h.postDelayed(dataScan,180L);
    }
  }

  // Prefer Android's system-level actions: Samsung can ignore ordinary
  // swipe gestures when the screen has just been turned on/locked.
  private void pullShadeDown(int pass){
    if(stage!=WAKING||!active()||power==null||!power.isInteractive())return;
    if(pass==0){
      boolean opened=performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS);
      Log.i(TAG,"Open notification shade, request accepted="+opened);
      if(!opened){
        gesturePullShade(0);
        return;
      }
      panelSequence=()->{
        panelSequence=null;
        pullShadeDown(1);
      };
      h.postDelayed(panelSequence,450L);
    }else{
      boolean opened=performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS);
      Log.i(TAG,"Open full quick settings, request accepted="+opened);
      if(!opened){
        gesturePullShade(1);
        return;
      }
      panelSequence=()->{
        panelSequence=null;
        if(stage!=WAKING||!active())return;
        AccessibilityNodeInfo sys=findSystemUiRoot();
        if(sys==null||findMobileDataTile(sys)==null){
          // A successful global action does not prove the Samsung panel
          // actually opened. Try the gesture before giving up.
          gesturePullShade(1);
        }else{
          scanMobileTile();
        }
      };
      h.postDelayed(panelSequence,400L);
    }
  }

  private void gesturePullShade(int pass){
    if(stage!=WAKING||!active()||power==null||!power.isInteractive())return;
    try{
      int width=getResources().getDisplayMetrics().widthPixels;
      int height=getResources().getDisplayMetrics().heightPixels;
      if(width<=0||height<=0){scanMobileTile();return;}
      float x=width*0.50f;
      float top=pass==0?Math.max(4f,height*0.012f):height*0.14f;
      Path path=new Path();
      path.moveTo(x,top);
      path.lineTo(x,height*0.80f);
      GestureDescription.Builder builder=new GestureDescription.Builder();
      builder.addStroke(new GestureDescription.StrokeDescription(path,0L,380L));
      boolean sent=dispatchGesture(builder.build(),new GestureResultCallback(){
        @Override public void onCompleted(GestureDescription g){
          if(stage!=WAKING||!active())return;
          if(pass==0){
            panelSequence=()->{panelSequence=null;pullShadeDown(1);};
            h.postDelayed(panelSequence,250L);
          }else{
            scanMobileTile();
          }
        }
        @Override public void onCancelled(GestureDescription g){
          Log.w(TAG,"Samsung shade swipe cancelled, step "+pass);
          if(pass==0){
            panelSequence=()->{panelSequence=null;pullShadeDown(1);};
            h.postDelayed(panelSequence,250L);
          }else{
            scanMobileTile();
          }
        }
      },h);
      if(!sent){
        Log.w(TAG,"Samsung shade gesture rejected, step "+pass);
        if(pass==0){
          panelSequence=()->{panelSequence=null;pullShadeDown(1);};
          h.postDelayed(panelSequence,250L);
        }else{
          scanMobileTile();
        }
      }
    }catch(RuntimeException ex){
      Log.w(TAG,"Samsung quick settings gesture failed",ex);
      if(pass==0){
        panelSequence=()->{panelSequence=null;pullShadeDown(1);};
        h.postDelayed(panelSequence,250L);
      }else{
        scanMobileTile();
      }
    }
  }

  private AccessibilityNodeInfo findSystemUiRoot(){
    AccessibilityNodeInfo root=getRootInActiveWindow();
    if(root!=null&&isSystemUi(root))return root;
    try{
      for(AccessibilityWindowInfo window:getWindows()){
        if(window==null)continue;
        AccessibilityNodeInfo view=window.getRoot();
        if(view!=null&&isSystemUi(view))return view;
      }
    }catch(RuntimeException e){
      Log.w(TAG,"Cannot retrieve quick settings windows",e);
    }
    return null;
  }

  private boolean isSystemUi(AccessibilityNodeInfo node){
    CharSequence pkg=node.getPackageName();
    return pkg!=null&&pkg.toString().toLowerCase(Locale.ROOT)
      .contains("systemui");
  }

  private String label(AccessibilityNodeInfo n){
    String t=n.getText()==null?"":n.getText().toString();
    String d=n.getContentDescription()==null?"":n.getContentDescription().toString();
    return (t+" "+d).toLowerCase(Locale.ROOT).trim();
  }

  // The Samsung A71 Italian quick tile is labelled "Conn. dati".
  private boolean mobileTileLabel(String s){
    String t=s.replaceAll("\\s+"," ").trim();
    return t.startsWith("conn. dati") ||
      t.startsWith("conn dati") ||
      t.startsWith("connessione dati") ||
      t.startsWith("dati mobili") ||
      t.startsWith("mobile data");
  }

  private AccessibilityNodeInfo findMobileDataTile(AccessibilityNodeInfo root){
    ArrayDeque<AccessibilityNodeInfo> nodes=new ArrayDeque<>();
    nodes.add(root);
    int count=0;
    while(!nodes.isEmpty()&&count++<250){
      AccessibilityNodeInfo n=nodes.removeFirst();
      String l=label(n);
      if(l.length()<125&&mobileTileLabel(l))return n;
      for(int i=0;i<n.getChildCount();i++){
        AccessibilityNodeInfo c=n.getChild(i);
        if(c!=null)nodes.addLast(c);
      }
    }
    return null;
  }

  // Fallback: tap only inside the bounds of the labelled mobile-data tile,
  // never at a hard-coded coordinate that might hit a different setting.
  private boolean tapRecognisedTile(AccessibilityNodeInfo tile){
    try{
      Rect r=new Rect();
      tile.getBoundsInScreen(r);
      if(r.isEmpty())return false;
      Path p=new Path();
      p.moveTo(r.centerX(),r.centerY());
      GestureDescription.Builder gesture=new GestureDescription.Builder();
      gesture.addStroke(new GestureDescription.StrokeDescription(p,0,80L));
      return dispatchGesture(gesture.build(),null,null);
    }catch(RuntimeException ex){
      Log.w(TAG,"Cannot tap recognised mobile data tile",ex);
      return false;
    }
  }

  private AccessibilityNodeInfo clickableAncestor(AccessibilityNodeInfo node){
    AccessibilityNodeInfo current=node;
    for(int i=0;i<5&&current!=null;i++){
      if(current.isClickable()&&current.isEnabled())return current;
      current=current.getParent();
    }
    return null;
  }

  // Samsung One UI shows a detail sheet called "Connessione dati"
  // with a blue checked ON switch, not a "Disattiva" button.
  private void tryConfirmDataOff(AccessibilityNodeInfo root){
    ArrayDeque<AccessibilityNodeInfo> nodes=new ArrayDeque<>();
    nodes.add(root);
    boolean detailOpen=false;
    boolean mentionsMobile=false;
    AccessibilityNodeInfo switchOn=null;
    AccessibilityNodeInfo rowOn=null;
    AccessibilityNodeInfo confirmation=null;
    int count=0;
    while(!nodes.isEmpty()&&count++<350){
      AccessibilityNodeInfo n=nodes.removeFirst();
      String s=label(n);
      if(s.contains("connessione dati")||s.contains("conn. dati")||
         s.contains("dati mobili")||s.contains("mobile data")){
        mentionsMobile=true;
        if(s.startsWith("connessione dati")&&s.length()<95)
          detailOpen=true;
      }
      CharSequence cls=n.getClassName();
      String type=cls==null?"":cls.toString().toLowerCase(Locale.ROOT);
      if(n.isVisibleToUser()&&n.isCheckable()&&n.isChecked()&&
         (type.contains("switch")||type.contains("togglebutton")))
        switchOn=n;
      if(n.isVisibleToUser()&&(s.equals("si")||s.equals("sì")||
          s.equals("on")||s.equals("attivo")))
        rowOn=n;
      if(s.equals("disattiva")||s.equals("turn off")||
         s.equals("disattiva dati mobili")||
         s.equals("disattiva connessione dati")||
         s.equals("turn off mobile data"))
        confirmation=clickableAncestor(n);
      for(int i=0;i<n.getChildCount();i++){
        AccessibilityNodeInfo child=n.getChild(i);
        if(child!=null)nodes.addLast(child);
      }
    }
    if(detailOpen&&!detailToggleAttempted){
      boolean clicked=false;
      if(switchOn!=null){
        AccessibilityNodeInfo target=clickableAncestor(switchOn);
        if(target!=null)
          clicked=target.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        if(!clicked)clicked=tapRecognisedTile(switchOn);
      }else if(rowOn!=null){
        clicked=tapMobileDataRowSwitch(rowOn);
      }
      if(clicked){
        detailToggleAttempted=true;
        Log.i(TAG,"Samsung Connessione dati switch OFF tap requested");
      }
    }
    if(mentionsMobile&&confirmation!=null&&!confirmationClicked){
      if(confirmation.performAction(AccessibilityNodeInfo.ACTION_CLICK)){
        confirmationClicked=true;
        Log.i(TAG,"Confirmed mobile data OFF");
      }
    }
  }

  // Fallback for Samsung custom rows exposing only a "Si" label:
  // identify the wide toggle row by its accessibility bounds.
  private boolean tapMobileDataRowSwitch(AccessibilityNodeInfo labelNode){
    try{
      int width=getResources().getDisplayMetrics().widthPixels;
      int height=getResources().getDisplayMetrics().heightPixels;
      AccessibilityNodeInfo node=labelNode;
      Rect rect=new Rect();
      for(int i=0;i<5&&node!=null;i++){
        node.getBoundsInScreen(rect);
        if(rect.width()>width*0.55f&&rect.height()>28&&
           rect.height()<height*0.20f){
          int x=rect.right-Math.max(24,(int)(rect.width()*0.09f));
          int y=rect.centerY();
          Path path=new Path();
          path.moveTo(x,y);
          GestureDescription.Builder g=new GestureDescription.Builder();
          g.addStroke(new GestureDescription.StrokeDescription(path,0L,80L));
          return dispatchGesture(g.build(),null,h);
        }
        node=node.getParent();
      }
    }catch(RuntimeException ex){
      Log.w(TAG,"Cannot tap Samsung mobile data switch",ex);
    }
    return false;
  }

  private void expandQuickPanel(){
    try{
      int w=getResources().getDisplayMetrics().widthPixels;
      int hgt=getResources().getDisplayMetrics().heightPixels;
      Path p=new Path();
      p.moveTo(w*0.50f,hgt*0.16f);
      p.lineTo(w*0.50f,hgt*0.78f);
      GestureDescription.Builder b=new GestureDescription.Builder();
      b.addStroke(new GestureDescription.StrokeDescription(p,0,300L));
      dispatchGesture(b.build(),null,null);
    }catch(RuntimeException ex){
      Log.w(TAG,"Quick settings swipe unavailable",ex);
    }
  }

  private void releaseDisplay(){
    if(display!=null){
      try{if(display.isHeld())display.release();}
      catch(RuntimeException ignored){}
      display=null;
    }
  }

  private void reset(){
    if(pendingWake!=null)h.removeCallbacks(pendingWake);
    if(pendingOff!=null)h.removeCallbacks(pendingOff);
    if(pendingFallback!=null)h.removeCallbacks(pendingFallback);
    if(dataScan!=null)h.removeCallbacks(dataScan);
    if(panelSequence!=null)h.removeCallbacks(panelSequence);
    pendingWake=pendingOff=pendingFallback=dataScan=panelSequence=null;
    dataAttemptStarted=dataTileClicked=expanded=confirmationClicked=detailToggleAttempted=false;
    scans=0;stage=IDLE;
    releaseDisplay();
    if(cpu!=null){
      try{if(cpu.isHeld())cpu.release();}
      catch(RuntimeException ignored){}
      cpu=null;
    }
  }

  @Override public void onAccessibilityEvent(AccessibilityEvent e){}
  @Override public void onInterrupt(){}
  @Override public void onDestroy(){
    reset();
    if(registered){
      try{unregisterReceiver(listener);}
      catch(IllegalArgumentException ignored){}
      registered=false;
    }
    if(instance==this)instance=null;
    super.onDestroy();
  }
}