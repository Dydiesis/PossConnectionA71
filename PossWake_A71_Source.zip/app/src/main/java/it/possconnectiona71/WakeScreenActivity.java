package it.possconnectiona71;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.WindowManager;
public class WakeScreenActivity extends Activity {
  private final Handler h=new Handler(Looper.getMainLooper());
  private final Runnable close=this::closeWake;
  @Override protected void onCreate(Bundle state){
    super.onCreate(state);
    setShowWhenLocked(true);setTurnScreenOn(true);
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED|
      WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON|WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
  }
  @Override protected void onResume(){
    super.onResume();ScreenWakeService.onWakeActivityVisible();
    h.removeCallbacks(close);h.postDelayed(close,6500L);
  }
  private void closeWake(){
    getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON|WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
    setTurnScreenOn(false);finish();overridePendingTransition(0,0);
  }
  @Override protected void onDestroy(){h.removeCallbacks(close);super.onDestroy();}
}