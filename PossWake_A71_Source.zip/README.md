# PossWake A71 — PossConnectionA71

Applicazione Android per Samsung Galaxy A71.

## Comportamento

1. Si spegne lo schermo (pulsante laterale o standby automatico).
2. Dopo **3 secondi** si riaccende automaticamente, senza sbloccare il telefono.
3. Rimane acceso **3 secondi**.
4. Il servizio Accessibility esegue `GLOBAL_ACTION_LOCK_SCREEN` per spegnerlo e lasciarlo bloccato.
5. Lo spegnimento generato dall'app **non** avvia un nuovo ciclo (niente loop).

Se si riaccende o sblocca manualmente nel frattempo, il ciclo viene annullato.
Il monitoraggio funziona anche con lo schermo spento, finché il servizio di Accessibilità rimane attivo.

## Configurazione iniziale

1. Installa l'APK scaricato dagli Artifacts del workflow GitHub Actions.
2. Apri **PossWake A71** e tocca **ATTIVA**.
3. In Impostazioni > Accessibilità > App installate abilita **PossWake A71 – controllo schermo**.
4. Torna nell'app. Comparirà **ATTIVO**; spegni lo schermo per provare.
5. Se il servizio viene terminato dal risparmio energetico Samsung, in Impostazioni > Applicazioni > PossWake A71 > Batteria scegli **Senza restrizioni** (se disponibile). Evita di disattivare il servizio di Accessibilità.

Per disattivare, apri l'app e tocca **DISATTIVA**.

## Limitazioni

- Utilizza una wake lock storica (`ACQUIRE_CAUSES_WAKEUP`) che Samsung/Android potrebbero limitare. Non è stato possibile collaudare fisicamente l'APK su un Galaxy A71.
- Il sistema può introdurre lievi scostamenti dai 3 secondi nominali.
- La disattivazione dello schermo allo scadere richiede il servizio di Accessibilità attivo.
- Non vengono raccolti dati; non servono Internet, account, notifiche o permessi di lettura dello schermo.

## Build locale

Con JDK 17, Android SDK 35 e Gradle 8.10.2: `gradle assembleDebug`.
APK: `app/build/outputs/apk/debug/app-debug.apk`.

## Metodo Possy

Il repository GitHub deve contenere `.github/workflows/build.yml` **fuori** dall'archivio ZIP. Carica nella root del repo **un solo ZIP** col nome `PossWake_A71_Source.zip`, senza estrarlo, usando **Add file > Upload files > Commit changes**. A ogni upload/aggiornamento di ZIP, il workflow si avvia automaticamente e pubblica l'APK nel **Artifact 1**.
